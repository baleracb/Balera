package myapplication.com.f.myapplication.app_nota;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class escreveMsg extends Activity {

    EditText edittext;
    Button button;

    public void telaPrincipal(View view){
        Intent intent1 = new Intent(getApplicationContext(), telaPrincipal.class);
        startActivity(intent1);
    }

    //Define a variável do EditText
    private EditText txtDigite;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escreve_msg);

        button = (Button)findViewById(R.id.btnClear);
        edittext = (EditText)findViewById(R.id.txtDigite);

        button.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View v) {
                edittext.getText().clear();

            }
        });

        //Chama a variável EditText
        txtDigite = (EditText) findViewById(R.id.txtDigite);

        ///Comando para criar o botão de voltar para a tela principal
        Button botao1 = (Button) findViewById(R.id.btnVoltar);
        botao1.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(escreveMsg.this, telaPrincipal.class);
                startActivity(it);
            }
        });

    }

    //Botão que exibe um TOAST quando o btnSalvar é clicado
    public void showMessage(View view){

        Toast.makeText(escreveMsg.this, "Você digitou: "+ txtDigite.getText(), Toast.LENGTH_LONG).show();
    }

}
