package myapplication.com.f.myapplication.app_nota;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import java.io.File;
import java.io.IOException;



public class foto extends AppCompatActivity {


    private ImageView imagem;
    private final int GALERIA_IMAGENS = 1;
    private final int PERMISSAO_REQUEST = 2;
    private final int TIRAR_FOTO = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__tirar__foto);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                imagem = (ImageView)findViewById(R.id.ivImagem);
                Button galeria = (Button)findViewById(R.id.btnImagem);
                galeria.setOnClickListener(new View.OnClickListener()){
                    @Override
                            public void onClick(View v){
                        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(Intent, GALERIA_IMAGENS);
                    }
                }


            }
        });

        Button foto = (Button) findViewById(R.id.btnFoto);
        foto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            }
                if(takePictureIntent.resolveActivity(

            getPackageManager())!=null)

            {
                try {
                    arquivoFoto = criarArquivo();
                } catch (IOExceptionex) {//  Manipulação  em  caso  de  falha  de  criação  do  arquivo
                }
                if (arquivoFoto != null) {
                    Uri photoURI = FileProvider.getUriForFile(getBaseContext(),
                            getBaseContext().getApplicationContext().getPackageName() +
                                    ".provider", arquivoFoto);
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    startActivityForResult(takePictureIntent, CAMERA);
                }
            }
        }
    });

}     //https://www.youtube.com/watch?v=o0ZKQITPnpk


    private File arquivoFoto = null;

    private File criarArquivo() throws IOException {
        String timeStamp = newSimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
    }

    File pasta = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
    File imagem = new File(pasta.getPath() + File.separator + "JPG_" + timeStamp + ".jpg");
        return imagem;
                }


@Override
protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode==RESULT_OK&&requestCode==GALERIA_IMAGENS){
        URI selectedImage=data.getData();
        String[]filePath={MediaStore.Images.Media.DATA};
        Cursor c=getContentResolver().query(selectedImage,filePath,null,null,null);
        c.moveToFirst();
        int columnIndex=c.getColumnIndex(filePath[0]);
        String picturePach=c.getString(columnIndex);
        c.close();
        Bitmap imagemGaleria=(BitmapFactory.decodeFile(picturePach));
        imagem.setImageBitmap(imagemGaleria);
        }
        if(requestCode==TIRAR_FOTO&&resultCode==RESULT_OK){
        Bundle extras=data.getExtras();
        Bitmap imageBitmap=(Bitmap)extras.get("data");
        imagem.setImageBitmap(imageBitmap);
        }
        }

        }


