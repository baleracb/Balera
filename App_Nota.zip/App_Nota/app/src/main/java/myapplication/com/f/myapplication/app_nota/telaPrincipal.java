package myapplication.com.f.myapplication.app_nota;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class telaPrincipal extends AppCompatActivity {

        @Override
        protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);

        Button botaoEscreveMsg = (Button) findViewById(R.id.btnEscreveMsg);
        botaoEscreveMsg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(telaPrincipal.this, escreveMsg.class);
                startActivity(it);
            }
        });

            Button botaoACC = (Button) findViewById(R.id.btnAcc);
            botaoACC.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent it = new Intent(telaPrincipal.this, telaAcc.class);
                    startActivity(it);
                }
            });

            Button botaoSalvar = (Button) findViewById(R.id.btnIrSalva);
            botaoSalvar.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent it = new Intent(telaPrincipal.this, telaTexto.class);
                    startActivity(it);
                }
            });



        /*Aqui mostra a tela de boas vindas*/
        Toast.makeText(getApplicationContext(), "-> SEJA BEM VINDO <-", Toast.LENGTH_LONG).show();


    }



    }


