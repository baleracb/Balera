package myapplication.com.f.myapplication.app_nota;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class telaTexto extends AppCompatActivity {



    public TextView arqTxt;

    public EditText txtDigitado;
    public EditText nomeArqTxt;
    public Button btnSalvarTxt;
    public Button btnLer1;
    public Button btnExcluir;
    public TextView conteudoArquivo;


    @Override
   public void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
       super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_tela_texto);

        txtDigitado = (EditText) findViewById(R.id.txtDigitado);
        nomeArqTxt = (EditText) findViewById(R.id.nomeArqTxt);
        btnSalvarTxt = (Button) findViewById(R.id.btnSalvarTxt);
        btnLer1 = (Button) findViewById(R.id.btnFoto);
        //btnExcluir = (Button) findViewById(R.id.btnExcluir);
        conteudoArquivo = (TextView) findViewById(R.id.conteudoArquivo);


        btnSalvarTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                try  {
                    EditText nomeArquivo = (EditText) findViewById(R.id.nomeArqTxt);
                    EditText txtDigitado = (EditText) findViewById(R.id.txtDigitado);

                    FileOutputStream gravarTexto = openFileOutput(nomeArqTxt.getText().toString(), MODE_PRIVATE);
                    String conteudoTxt = txtDigitado.getText().toString();
                    gravarTexto.write(conteudoTxt.getBytes());
                    gravarTexto.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Toast.makeText(telaTexto.this, "Arquivo Gravado Com Sucesso", Toast.LENGTH_LONG).show();
                nomeArqTxt.getText().clear();
                txtDigitado.getText().clear();
                //Intent intent = new Intent(telaTexto.this, MainActivity.class);
                //startActivity(intent);

            }
        });


        btnLer1.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try  {
                    EditText nomeArquivo = (EditText) findViewById(R.id.nomeArqTxt);
                    EditText txtDigitado = (EditText) findViewById(R.id.txtDigitado);
                    TextView conteudoArquivo = (TextView)findViewById(R.id.conteudoArquivo);

                    File arquivoRecuperado = getFileStreamPath(nomeArquivo.getText().toString());
                    if (arquivoRecuperado.exists()) {
                        FileInputStream arqRacuperado = openFileInput(nomeArqTxt.getText().toString());
                        int tamanhoArquivo = arqRacuperado.available();
                        byte dadosBytesLidos[] = new byte[tamanhoArquivo];
                        arqRacuperado.read(dadosBytesLidos);
                        String txtLido = new String(dadosBytesLidos);
                        txtDigitado.setText(txtLido);
                        arqRacuperado.close();
                        }else {
                        Toast.makeText(telaTexto.this, "Arquivo não encontrado", Toast.LENGTH_LONG).show();
                        }
                        } catch (FileNotFoundException e) {
                         e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        /*btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText nomeArquivo = (EditText)findViewById(R.id.nomeArqTxt);
                boolean exclusao = deleteFile(nomeArqTxt.getText().toString());
                if(exclusao)
                    Toast.makeText(telaTexto.this, "Arquivo excluido com sucesso", Toast.LENGTH_LONG).show();
                 else
                    Toast.makeText(telaTexto.this, "Arquivo não encontrado para exclusão", Toast.LENGTH_LONG).show();


            }
        });*/




    }
}

